package com.peakmain.analytics.plugin.utils

import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes
import org.objectweb.asm.Type

class NetworkFieldUtils {
    public static final String OWNER_QI_NIU_HTTP_USER_AGENT = "com/qiniu/android/http/UserAgent"
    public static final String NAME_QI_NIU_HTTP_USER_AGENT = "getUa"
    public static final String DESCRIPTOR_QI_NIU_HTTP_USER_AGENT = "(Ljava/lang/String;)Ljava/lang/String;"
    public static final String DESC_QI_NIU= OWNER_QI_NIU_HTTP_USER_AGENT+ NAME_QI_NIU_HTTP_USER_AGENT


    //替换的类和方法
    public static final String OWNER_NEW_QI_NIU_HTTP_USER_AGENT = "com/peakmain/sdk/utils/network/UserAgent"
    public static final String DESCRIPTOR_NEW_QI_NIU_HTTP_USER_AGENT = "(Lcom/qiniu/android/http/UserAgent;Ljava/lang/String;)Ljava/lang/String;"

    /**
     * 清空方法体
     */
    static void clearMethodBody(MethodVisitor mv,  int access, String descriptor) {
        Type type = Type.getType(descriptor)
        Type methodType = Type.getType(descriptor)
        Type methodReturnType = methodType.getReturnType()
        Type[] argumentsType = type.getArgumentTypes()
        Type returnType = type.getReturnType()
        int stackSize = returnType.getSize()
        int localSize = OpcodesUtils.isStatic(access) ? 0 : 1
        for (Type argType : argumentsType) {
            localSize += argType.size
        }
        mv.visitCode()
        if (methodReturnType.getSort() == Type.VOID) {
            mv.visitInsn(Opcodes.RETURN)
        } else if (methodReturnType.getSort() >= Type.BOOLEAN && methodReturnType.getSort() <= Type.DOUBLE) {
            mv.visitInsn(methodReturnType.getOpcode(Opcodes.ICONST_1))
            mv.visitInsn(methodReturnType.getOpcode(Opcodes.IRETURN))
        } else if (methodReturnType.getInternalName() == "java/lang/String") {
            mv.visitLdcInsn("")
            mv.visitInsn(Opcodes.ARETURN)
        } else {
            mv.visitInsn(Opcodes.ACONST_NULL)
            mv.visitInsn(Opcodes.ARETURN)
        }
        mv.visitMaxs(stackSize, localSize)
        mv.visitEnd()
    }
}